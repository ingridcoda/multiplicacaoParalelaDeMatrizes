package multiplicaMatrizes;

import java.util.concurrent.Callable;

/* Classe de implementa��o do c�lculo da multiplica��o de uma linha 
 * por uma coluna de uma matriz, usando a interface Callable */
public class Calculos implements Callable<Double> {
	
	/* Vari�veis auxiliares para o processamento */
	private double[] linha;
	private double[] coluna;
	private double resultado = 0;
	private long tempoInicial = System.currentTimeMillis();

	/* Construtor da classe de c�lculo */
	public Calculos (double[] linha, double[] coluna) {
		
		this.linha = new double[linha.length];
		this.coluna = new double[linha.length];
		
		for (int i = 0; i < linha.length; i++) {
			
			this.linha[i] = linha[i];
			this.coluna[i] = coluna[i];
			
		}
		
	}

	/* Sobrescrita do m�todo call() da interface Callable: 
	 * 
	 * Realiza o c�lculo, utilizando a f�rmula padr�o 
	 * da matem�tica para multiplicar matrizes */	 
	@Override
	public Double call() throws Exception {
		
		System.out.println("Thread " + Thread.currentThread().getName() + " iniciada.");
		System.out.println();
		
		long k = 0;
		
		while (k < 1000000000) {
			k++;
		}
		
		int i = 0;
		
		while (i < linha.length) {
			
			double l = linha[i];
			double c = coluna[i];
			this.resultado += l * c;
			i++;
			
		}
		
		System.out.println("Resultado da multiplica��o realizada pela thread " + Thread.currentThread().getName() + ": " + resultado);
		System.out.println();
		
		System.out.println("Tempo de execu��o da thread" + Thread.currentThread().getName() + ": " + (System.currentTimeMillis() - tempoInicial) + " milissegundos.");
		System.out.println();
		
		return resultado;
		
	}
		
}
