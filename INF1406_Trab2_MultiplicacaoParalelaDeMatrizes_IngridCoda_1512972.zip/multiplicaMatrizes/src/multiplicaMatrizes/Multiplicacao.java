package multiplicaMatrizes;

import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;


/* Classe principal */
public class Multiplicacao {
	
	private static long tempoInicial = System.currentTimeMillis();

	/* M�todo principal, onde � realizada a leitura do arquivo de matrizes, captura dos dados 
	 * das matrizes, envio para a classe de c�lculo (Thread Pool) para realiza��o do c�lculo 
	 * da multiplica��o das matrizes, captura dos resultados e escrita no arquivo de resultados */
	public static void main (String[] args) throws InterruptedException, ExecutionException {

		/* Par�metros do programa exigidos no enunciado*/
		String caminho = args[0];	
		int n = Integer.parseInt(args[1]);
		int maxThreads = Integer.parseInt(args[2]);
		int totalMatrizes = Integer.parseInt(args[3]);
		
		System.out.println("Dimens�o das matrizes : " + n + " X " + n);
		System.out.println("Total de matrizes contidas no arquivo : " + totalMatrizes);
		System.out.println("N�mero m�ximo de threads a serem usadas : " + maxThreads);
		System.out.println();
		
		/* Vari�veis auxiliares para processamento */
		List<double[][]> matrizes = new ArrayList<double[][]>();
		double[][] matrizAux;

		/* Cria��o do Thread Pool e lista de objetos fututos */
		ExecutorService executor = Executors.newFixedThreadPool(maxThreads);
		ArrayList<Future<Double>> list = new ArrayList<Future<Double>>();

		/* Vari�veis para manipula��o de arquivos */
		Scanner lerArquivo = null;
		PrintWriter escreverArquivo = null;

		try {

			lerArquivo = new Scanner(new FileReader(caminho));

			int w = 0;
			
			while (lerArquivo.hasNext()) {
				
				matrizAux = new double[n][n];
				
				for (int i = 0; i < n; i++) {

					for (int j = 0; j < n; j++) {

						matrizAux[i][j] = Double.parseDouble(lerArquivo.next());
					}

				}

				matrizes.add(matrizAux);				

				w++;
				
				if (w == totalMatrizes) {
					
					break;
					
				}

			}

			w = 0;			

			while (matrizes.size() != w) {

				matrizAux = matrizes.get(w);

				w++;

			}

		} catch (IOException e) {
			
			System.out.println("Erro ao ler arquivo de matrizes. Tente novamente!");
			System.out.println();
			System.out.println(e.getMessage());
			System.out.println();
			e.printStackTrace();
			
			System.exit(1);

		} finally {

			lerArquivo.close();

		}

		matrizAux = new double[n][n];

		for (int i = 0; i < n; i++){

			for (int j = 0; j < n; j++) {

				if (i == j) {
					
					matrizAux[i][j] = 1;
					
				} else {
					
					matrizAux[i][j] = 0;
					
				}

			}

		}


		for (double[][] mat: matrizes) {

			for (int i = 0; i < n; i++) {

				for (int x = 0; x < n; x++) {

					double coluna[] = new double[n];

					for (int j = 0; j < n; j++) {

						coluna[j] = mat[j][x];

					}

					Callable<Double> worker = new Calculos(matrizAux[i], coluna);
					Future<Double> submit = executor.submit(worker);
					list.add(submit);			

				}

			}

			for (int i = 0; i < n; i++) {
				
				for (int j = 0; j < n; j++) {
					
					matrizAux[i][j] = (list.get(n * i + j)).get();
					
				}
				
			}
			
			list.clear();

		}

		int cont = 0;
		
		try {

			escreverArquivo = new PrintWriter("resultado.txt");	
			lerArquivo = new Scanner(new FileReader(caminho));

			while (lerArquivo.hasNext()) {

				if (cont < n) {

					escreverArquivo.print(Double.parseDouble(lerArquivo.next()) + " ");
					cont++;

				} else {

					escreverArquivo.println();
					cont = 0;	

				}	

			}

			escreverArquivo.println();

			for (int i = 0; i < n; i++) {
				
				for (int j = 0; j < n; j++) {
					
					escreverArquivo.print(matrizAux[i][j]+ " ");
					
				}
				
				escreverArquivo.println();
				
			}
			
		} catch (IOException e) {
			
			System.out.println("Erro ao escrever em arquivo de resultados das multiplica��es. Tente novamente!");
			System.out.println();
			System.out.println(e.getMessage());
			System.out.println();
			e.printStackTrace();
			
			System.exit(1);
			
		} finally {
			
			escreverArquivo.close();
			
		}

		lerArquivo.close();			
		executor.shutdown();
		
		System.out.println("Processamento geral concluido!");
		System.out.println();
		System.out.println("Tempo de execu��o da thread principal: " + (System.currentTimeMillis() - tempoInicial) + " milissegundos.");

	}

}
